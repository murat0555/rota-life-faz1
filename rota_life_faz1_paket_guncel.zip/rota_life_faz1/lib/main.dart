import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:uuid/uuid.dart';
import 'firebase_options.dart';

final notifications = FlutterLocalNotificationsPlugin();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  await notifications.initialize(const InitializationSettings(
    android: AndroidInitializationSettings('@mipmap/ic_launcher'),
    iOS: DarwinInitializationSettings(),
  ));
  runApp(const RotaLifeApp());
}

class RotaLifeApp extends StatelessWidget {
  const RotaLifeApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Rota Life',
        theme: ThemeData.dark().copyWith(
          scaffoldBackgroundColor: const Color(0xFF0D0D0D),
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF39FF14), brightness: Brightness.dark),
          cardTheme: CardTheme(color: const Color(0xFF15191B), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22))),
          inputDecorationTheme: InputDecorationTheme(border: OutlineInputBorder(borderRadius: BorderRadius.circular(16))),
        ),
        home: const AuthGate(),
      );
}


class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<User?>(
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (context, snap) => snap.data == null ? const WelcomePage() : const DemoGate(),
      );
}

const countries = ['Türkiye', 'Almanya', 'Hollanda', 'Belçika', 'Fransa', 'İngiltere', 'Diğer'];


class DemoGate extends StatelessWidget {
  const DemoGate({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<DocumentSnapshot<Map<String,dynamic>>>(
    stream: userDoc().snapshots(),
    builder: (context, snap) {
      final data = snap.data?.data();
      final status = data?['demoStatus'] ?? 'not_requested';
      final accountStatus = data?['accountStatus'] ?? 'demo_required';
      if (status == 'approved' && accountStatus == 'active') return const ShellPage();
      return DemoRequestPage(status: status.toString(), selectedPlan: (data?['selectedPlan'] ?? 'free').toString());
    });
}

class DemoRequestPage extends StatefulWidget {
  final String status; final String selectedPlan;
  const DemoRequestPage({super.key, required this.status, required this.selectedPlan});
  @override State<DemoRequestPage> createState() => _DemoRequestPageState();
}
class _DemoRequestPageState extends State<DemoRequestPage> {
  final company = TextEditingController();
  final note = TextEditingController();
  String plan = 'Life Pro'; bool busy=false;
  Future<void> submit() async {
    setState(()=>busy=true);
    try {
      final u = FirebaseAuth.instance.currentUser!;
      await FirebaseFirestore.instance.collection('demoRequests').doc(u.uid).set({
        'uid': u.uid,
        'email': u.email,
        'phone': u.phoneNumber,
        'displayName': u.displayName,
        'company': company.text.trim(),
        'note': note.text.trim(),
        'requestedPlan': plan,
        'status': 'pending',
        'requestedAt': FieldValue.serverTimestamp(),
        'adminEmailToNotify': 'ADMIN_EMAIL_BURAYA'
      }, SetOptions(merge: true));
      await userDoc().set({'demoStatus':'pending','selectedPlan':plan,'accountStatus':'waiting_admin_approval','updatedAt':FieldValue.serverTimestamp()}, SetOptions(merge:true));
      if(mounted) snack(context, 'Demo talebin alındı. Yönetici onayından sonra giriş aktif olur.');
    } catch(e) { if(mounted) snack(context, 'Demo talebi hatası: $e'); }
    if(mounted) setState(()=>busy=false);
  }
  @override Widget build(BuildContext context) => Scaffold(body: SafeArea(child: ListView(padding: const EdgeInsets.all(20), children: [
    Row(children:[const Icon(Icons.radar,color:Color(0xFF39FF14)), const SizedBox(width:10), const Expanded(child:Text('ROTA LIFE Demo Onayı', style:TextStyle(fontSize:26,fontWeight:FontWeight.bold))), IconButton(onPressed:()=>FirebaseAuth.instance.signOut(), icon: const Icon(Icons.logout))]),
    const SizedBox(height: 14),
    infoCard('Hesap Durumu', widget.status == 'pending' ? 'Demo talebin beklemede. Yönetici onay verdiğinde uygulama açılır.' : 'Uygulamayı kullanmak için demo talebi oluşturmalısın.'),
    DropdownButtonFormField<String>(value: plan, decoration: const InputDecoration(labelText:'Demo istediğin paket'), items: const [
      DropdownMenuItem(value:'Life Pro', child:Text('Life Pro - Aile / bireysel')),
      DropdownMenuItem(value:'Araç Pro', child:Text('Araç Pro - Araç / filo')),
      DropdownMenuItem(value:'Kurumsal', child:Text('Kurumsal - işletme')),
    ], onChanged:(v)=>setState(()=>plan=v ?? 'Life Pro')),
    const SizedBox(height: 10),
    TextField(controller: company, decoration: const InputDecoration(labelText:'Firma / kullanım adı')), const SizedBox(height:10),
    TextField(controller: note, minLines: 3, maxLines: 5, decoration: const InputDecoration(labelText:'Demo talebi notu: ne için kullanacaksın?')),
    const SizedBox(height: 14),
    SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: busy?null:submit, icon: const Icon(Icons.send), label: const Text('Demo Talebi Gönder'))),
    const SizedBox(height: 16),
    infoCard('Yönetici Onayı Nasıl Çalışır?', 'Firestore > demoRequests > kullanıcının kaydında status=approved yapılır. Aynı anda users > UID içinde demoStatus=approved ve accountStatus=active yapılır. Cloud Functions eklenirse yöneticiye otomatik e-posta gider.'),
  ])));
}


class WelcomePage extends StatelessWidget {
  const WelcomePage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: Column(children: [
          Container(padding: const EdgeInsets.all(24), decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: const Color(0xFF39FF14), width: 2), boxShadow: const [BoxShadow(color: Color(0x5539FF14), blurRadius: 32)]), child: const Icon(Icons.radar, size: 84, color: Color(0xFF39FF14))),
          const SizedBox(height: 22),
          const Text('ROTA LIFE', style: TextStyle(fontSize: 38, fontWeight: FontWeight.w900, letterSpacing: 2)),
          const SizedBox(height: 8),
          const Text('Hayatını, konumunu, görevlerini ve acil durumlarını tek panelden yönet.', textAlign: TextAlign.center),
          const SizedBox(height: 32),
          SizedBox(width: double.infinity, child: FilledButton.icon(icon: const Icon(Icons.login), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoginPage())), label: const Text('Giriş Yap'))),
          const SizedBox(height: 12),
          SizedBox(width: double.infinity, child: OutlinedButton.icon(icon: const Icon(Icons.person_add_alt_1), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RegisterPage())), label: const Text('Kayıt Ol'))),
        ])))));
}

class LoginPage extends StatefulWidget { const LoginPage({super.key}); @override State<LoginPage> createState() => _LoginPageState(); }
class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController(); final pass = TextEditingController(); bool busy = false;
  Future<void> login() async { setState(() => busy = true); try { await FirebaseAuth.instance.signInWithEmailAndPassword(email: email.text.trim(), password: pass.text); if (mounted) Navigator.pop(context); } catch (e) { if (mounted) snack(context, 'Giriş hatası: $e'); } if (mounted) setState(() => busy = false); }
  Future<void> resetPassword() async { if (email.text.trim().isEmpty) { snack(context, 'Önce e-posta adresini yaz.'); return; } await FirebaseAuth.instance.sendPasswordResetEmail(email: email.text.trim()); if (mounted) snack(context, 'Şifre sıfırlama bağlantısı gönderildi.'); }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Giriş Yap')), body: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: Column(children: [
    const Icon(Icons.lock_open, size: 72, color: Color(0xFF39FF14)), const SizedBox(height: 18),
    TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'E-posta')),
    const SizedBox(height: 12), TextField(controller: pass, obscureText: true, decoration: const InputDecoration(labelText: 'Şifre')),
    const SizedBox(height: 20), SizedBox(width: double.infinity, child: FilledButton(onPressed: busy ? null : login, child: const Text('Giriş Yap'))),
    TextButton(onPressed: resetPassword, child: const Text('Şifremi Unuttum')),
  ]))));
}

class RegisterPage extends StatefulWidget { const RegisterPage({super.key}); @override State<RegisterPage> createState() => _RegisterPageState(); }
class _RegisterPageState extends State<RegisterPage> with SingleTickerProviderStateMixin {
  late final TabController tab;
  final name = TextEditingController(), email = TextEditingController(), pass = TextEditingController(), phone = TextEditingController(), smsCode = TextEditingController();
  String country = 'Türkiye'; bool kvkkRead = false, explicitConsent = false, terms = false, marketing = false, busy = false; String? verificationId;
  @override void initState(){ super.initState(); tab = TabController(length: 3, vsync: this); }
  bool get approvalsOk => kvkkRead && explicitConsent && terms;
  Map<String,dynamic> consentPayload(String method) => {'country': country, 'authMethod': method, 'kvkkAydinlatmaOkundu': kvkkRead, 'acikRizaOnayi': explicitConsent, 'uyelikKosullariOnayi': terms, 'ticariIletiOnayi': marketing, 'consentVersion': 'rota-life-faz1-2026-05-09', 'consentAt': FieldValue.serverTimestamp()};
  Future<void> saveProfile(User user, String method) async { await FirebaseFirestore.instance.collection('users').doc(user.uid).set({'uid': user.uid, 'displayName': name.text.trim().isEmpty ? (user.displayName ?? 'Rota Life Kullanıcısı') : name.text.trim(), 'email': user.email ?? email.text.trim(), 'phone': user.phoneNumber ?? phone.text.trim(), 'country': country, 'createdAt': FieldValue.serverTimestamp(), 'updatedAt': FieldValue.serverTimestamp(), 'demoStatus': 'not_requested', 'selectedPlan': 'free', 'accountStatus': 'demo_required', ...consentPayload(method)}, SetOptions(merge: true)); }
  void requireConsent() { if (!approvalsOk) throw Exception('KVKK Aydınlatma, Açık Rıza ve Üyelik Koşulları onaylanmalıdır.'); }
  Future<void> registerEmail() async { setState(()=>busy=true); try { requireConsent(); final c=await FirebaseAuth.instance.createUserWithEmailAndPassword(email: email.text.trim(), password: pass.text); await c.user!.sendEmailVerification(); await saveProfile(c.user!, 'email'); if(mounted) snack(context,'Kayıt tamam. E-posta doğrulama bağlantısı gönderildi.'); } catch(e){ if(mounted) snack(context,'Kayıt hatası: $e'); } if(mounted) setState(()=>busy=false); }
  Future<void> registerGoogle() async { setState(()=>busy=true); try { requireConsent(); final account=await GoogleSignIn().signIn(); if(account==null) return; final auth=await account.authentication; final credential=GoogleAuthProvider.credential(accessToken: auth.accessToken, idToken: auth.idToken); final c=await FirebaseAuth.instance.signInWithCredential(credential); await saveProfile(c.user!, 'google'); } catch(e){ if(mounted) snack(context,'Google kayıt hatası: $e'); } if(mounted) setState(()=>busy=false); }
  Future<void> sendSms() async { setState(()=>busy=true); try { requireConsent(); await FirebaseAuth.instance.verifyPhoneNumber(phoneNumber: phone.text.trim(), verificationCompleted: (cred) async { final c=await FirebaseAuth.instance.signInWithCredential(cred); await saveProfile(c.user!, 'phone_auto'); }, verificationFailed: (e){ snack(context,'SMS doğrulama hatası: ${e.message}'); }, codeSent: (id, token){ setState(()=>verificationId=id); snack(context,'SMS kodu gönderildi.'); }, codeAutoRetrievalTimeout: (id){ verificationId=id; }); } catch(e){ if(mounted) snack(context,'Telefon kayıt hatası: $e'); } if(mounted) setState(()=>busy=false); }
  Future<void> verifySmsCode() async { if(verificationId==null){ snack(context,'Önce SMS kodu gönder.'); return; } setState(()=>busy=true); try { final cred=PhoneAuthProvider.credential(verificationId: verificationId!, smsCode: smsCode.text.trim()); final c=await FirebaseAuth.instance.signInWithCredential(cred); await saveProfile(c.user!, 'phone_sms'); } catch(e){ if(mounted) snack(context,'Kod doğrulama hatası: $e'); } if(mounted) setState(()=>busy=false); }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Kayıt Ol'), bottom: TabBar(controller: tab, tabs: const [Tab(text:'E-posta'), Tab(text:'Telefon'), Tab(text:'Google')])), body: SafeArea(child: TabBarView(controller: tab, children: [
    registerForm(children:[TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText:'E-posta')), const SizedBox(height:10), TextField(controller: pass, obscureText:true, decoration: const InputDecoration(labelText:'Şifre - en az 6 karakter')), const SizedBox(height:14), FilledButton(onPressed: busy?null:registerEmail, child: const Text('E-posta ile Kayıt Ol'))]),
    registerForm(children:[TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText:'Telefon', hintText:'+905xxxxxxxxx')), const SizedBox(height:10), FilledButton(onPressed: busy?null:sendSms, child: const Text('SMS Kodu Gönder')), const SizedBox(height:10), TextField(controller: smsCode, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText:'SMS Kodu')), const SizedBox(height:10), OutlinedButton(onPressed: busy?null:verifySmsCode, child: const Text('Kodu Doğrula ve Kayıt Ol'))]),
    registerForm(children:[const Text('Google hesabıyla kayıt olmak için önce KVKK ve üyelik onaylarını işaretle.'), const SizedBox(height:14), FilledButton.icon(icon: const Icon(Icons.g_mobiledata), onPressed: busy?null:registerGoogle, label: const Text('Google ile Kayıt Ol'))]),
  ])));
  Widget registerForm({required List<Widget> children}) => ListView(padding: const EdgeInsets.all(16), children: [
    TextField(controller: name, decoration: const InputDecoration(labelText:'Ad Soyad / Profil adı')),
    const SizedBox(height:10), DropdownButtonFormField<String>(value: country, decoration: const InputDecoration(labelText:'Ülke'), items: countries.map((e)=>DropdownMenuItem(value:e, child:Text(e))).toList(), onChanged:(v)=>setState(()=>country=v??'Türkiye')),
    const SizedBox(height:14), ...children, const Divider(height:30),
    consentTile('KVKK Aydınlatma Metni’ni okudum.', kvkkRead, (v)=>setState(()=>kvkkRead=v??false), onOpen:()=>showLegal('KVKK Aydınlatma Metni', kvkkText)),
    consentTile('Kişisel verilerimin uygulama hizmetleri için işlenmesine açık rıza veriyorum.', explicitConsent, (v)=>setState(()=>explicitConsent=v??false), onOpen:()=>showLegal('Açık Rıza Metni', consentText)),
    consentTile('Üyelik koşullarını kabul ediyorum.', terms, (v)=>setState(()=>terms=v??false), onOpen:()=>showLegal('Üyelik Koşulları', termsText)),
    CheckboxListTile(value: marketing, onChanged:(v)=>setState(()=>marketing=v??false), title: const Text('Kampanya ve bilgilendirme iletileri almak istiyorum. (Opsiyonel)')),
  ]);
  Widget consentTile(String title, bool value, ValueChanged<bool?> onChanged, {required VoidCallback onOpen}) => CheckboxListTile(value:value, onChanged:onChanged, title: Text(title), subtitle: TextButton(onPressed:onOpen, child: const Text('Metni Oku')));
  void showLegal(String title, String body) => showModalBottomSheet(context: context, isScrollControlled:true, builder:(_)=>DraggableScrollableSheet(expand:false, initialChildSize:.82, builder:(c,sc)=>Padding(padding:const EdgeInsets.all(18), child:ListView(controller:sc, children:[Text(title, style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold)), const SizedBox(height:12), Text(body), const SizedBox(height:18), FilledButton(onPressed:()=>Navigator.pop(c), child: const Text('Kapat'))])));
}

const kvkkText = '''ROTA LIFE KVKK AYDINLATMA METNI TASLAĞI
Veri sorumlusu: [Şirket/Firma adı, adres, e-posta, telefon].
İşlenen veriler: ad soyad, e-posta, telefon, ülke, cihaz bilgileri, oturum bilgileri, canlı konum, görev/hatırlatıcı kayıtları, araç kayıtları, acil kişi bilgileri ve kullanıcı tarafından girilen notlar.
Amaçlar: üyelik oluşturma, kimlik doğrulama, canlı konum paylaşımı, acil durum bildirimi, görev/hatırlatıcı yönetimi, araç konum servisleri, güvenlik, hata analizi ve kullanıcı desteği.
Hukuki sebep: sözleşmenin kurulması/ifası, meşru menfaat, hukuki yükümlülük ve açık rıza gerektiren hallerde açık rıza.
Aktarım: Firebase/Google altyapı hizmetleri, harita/bildirim servisleri, yetkili kamu kurumları ve hizmet sağlayıcılar ile amaçla sınırlı paylaşım yapılabilir.
Haklar: KVKK madde 11 kapsamındaki başvuru, düzeltme, silme, itiraz ve bilgi talep hakları saklıdır.
Not: Bu metin taslaktır; yayına çıkmadan önce hukuk danışmanı tarafından firma bilgilerine göre düzenlenmelidir.''';
const consentText = '''AÇIK RIZA METNI TASLAĞI
Canlı konum, acil durum paylaşımı, harita servisleri, telefon/e-posta doğrulama ve uygulama bildirimleri için gerekli kişisel verilerimin Rota Life hizmetlerinin sunulması amacıyla işlenmesine izin veriyorum. Konum iznini cihaz ayarlarından kapatabileceğimi, pazarlama izninin opsiyonel olduğunu ve açık rızamı dilediğim zaman geri çekebileceğimi biliyorum.''';
const termsText = '''ÜYELİK KOŞULLARI TASLAĞI
Kullanıcı, uygulamaya doğru bilgi girmeyi, acil durum özelliğini kötüye kullanmamayı, cihaz izinlerini kendi sorumluluğunda yönetmeyi ve uygulamanın test/faz 1 sürümünde olduğunu kabul eder. Canlı konum, harita, SMS, WhatsApp ve arama işlemleri cihaz, operatör ve internet erişimine bağlıdır.''';

class ShellPage extends StatefulWidget { const ShellPage({super.key}); @override State<ShellPage> createState() => _ShellPageState(); }
class _ShellPageState extends State<ShellPage> {
  int index = 0;
  final pages = const [DashboardPage(), MapPage(), TasksPage(), EmergencyPage(), PricingPage(), SettingsPage()];
  @override Widget build(BuildContext context) => Scaffold(
    body: pages[index],
    bottomNavigationBar: NavigationBar(selectedIndex: index, onDestinationSelected: (v)=>setState(()=>index=v), destinations: const [
      NavigationDestination(icon: Icon(Icons.dashboard), label: 'Panel'),
      NavigationDestination(icon: Icon(Icons.map), label: 'Harita'),
      NavigationDestination(icon: Icon(Icons.task_alt), label: 'Görev'),
      NavigationDestination(icon: Icon(Icons.sos), label: 'Acil'),
      NavigationDestination(icon: Icon(Icons.payments), label: 'Paket'),
      NavigationDestination(icon: Icon(Icons.settings), label: 'Ayar'),
    ]));
}

String get uid => FirebaseAuth.instance.currentUser!.uid;
DocumentReference<Map<String,dynamic>> userDoc() => FirebaseFirestore.instance.collection('users').doc(uid);
CollectionReference<Map<String,dynamic>> col(String name) => userDoc().collection(name);
void snack(BuildContext c, String m) => ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m)));

class DashboardPage extends StatefulWidget { const DashboardPage({super.key}); @override State<DashboardPage> createState()=>_DashboardPageState(); }
class _DashboardPageState extends State<DashboardPage> {
  Position? pos; StreamSubscription<Position>? sub;
  @override void initState(){ super.initState(); startLocation(); }
  Future<void> startLocation() async {
    var perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) perm = await Geolocator.requestPermission();
    if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) return;
    sub = Geolocator.getPositionStream(locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, distanceFilter: 15)).listen((p) async {
      setState(()=>pos=p);
      await col('locations').doc('self').set({'lat':p.latitude,'lng':p.longitude,'speed':p.speed,'updatedAt':FieldValue.serverTimestamp()}, SetOptions(merge:true));
    });
  }
  @override void dispose(){ sub?.cancel(); super.dispose(); }
  @override Widget build(BuildContext context) => SafeArea(child: ListView(padding: const EdgeInsets.all(16), children: [
    Row(children:[const Icon(Icons.radar,color:Color(0xFF39FF14)), const SizedBox(width:10), const Expanded(child: Text('Rota Life Panel', style: TextStyle(fontSize:26,fontWeight:FontWeight.bold))), IconButton(onPressed:()=>FirebaseAuth.instance.signOut(), icon: const Icon(Icons.logout))]),
    const SizedBox(height: 16),
    heroCard('Canlı Konum', pos==null?'Konum bekleniyor':'${pos!.latitude.toStringAsFixed(5)}, ${pos!.longitude.toStringAsFixed(5)}', Icons.my_location),
    StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(stream: col('tasks').orderBy('date').limit(5).snapshots(), builder:(c,s)=> infoCard('Yaklaşan Görevler', s.data?.docs.map((d)=>'• ${d.data()['title'] ?? ''}').join('\n') ?? 'Görev yok')),
    StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(stream: col('vehicles').snapshots(), builder:(c,s)=> infoCard('Araç Konum Servisleri', s.data?.docs.map((d)=>'• ${d.data()['plate']}: ${d.data()['status'] ?? 'aktif'}').join('\n') ?? 'Araç eklenmedi')),
    infoCard('Acil Durum', 'SOS ekranından konum linki ile arama, SMS veya WhatsApp paylaşımı yapabilirsin.'),
  ]));
}

Widget heroCard(String t, String s, IconData i)=>Card(child:Padding(padding:const EdgeInsets.all(18),child:Row(children:[Icon(i,size:42,color:const Color(0xFF00FFFF)),const SizedBox(width:14),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(t,style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold)),Text(s)]))])));
Widget infoCard(String t, String s)=>Card(child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(t,style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold,color:Color(0xFF39FF14))),const SizedBox(height:8),Text(s.isEmpty?'Kayıt yok':s)])));

class MapPage extends StatefulWidget { const MapPage({super.key}); @override State<MapPage> createState()=>_MapPageState(); }
class _MapPageState extends State<MapPage>{
  LatLng center = const LatLng(41.0082, 28.9784);
  @override Widget build(BuildContext context)=>SafeArea(child:StreamBuilder<DocumentSnapshot<Map<String,dynamic>>>(stream: col('locations').doc('self').snapshots(), builder:(c,s){
    final data=s.data?.data(); if(data!=null) center=LatLng((data['lat']??41.0).toDouble(), (data['lng']??29.0).toDouble());
    return GoogleMap(initialCameraPosition: CameraPosition(target:center, zoom:15), markers:{Marker(markerId:const MarkerId('self'), position:center, infoWindow:const InfoWindow(title:'Benim Konumum'))}, myLocationEnabled:true, myLocationButtonEnabled:true);
  }));
}

class TasksPage extends StatelessWidget { const TasksPage({super.key});
  Future<void> add(BuildContext context) async { final t=TextEditingController(); DateTime date=DateTime.now().add(const Duration(hours:1));
    await showDialog(context: context, builder: (c)=>AlertDialog(title:const Text('Görev / Hatırlatıcı Ekle'), content:TextField(controller:t, decoration:const InputDecoration(labelText:'Başlık')), actions:[TextButton(onPressed:()=>Navigator.pop(c), child:const Text('İptal')), FilledButton(onPressed:() async{ final id=const Uuid().v4(); await col('tasks').doc(id).set({'title':t.text,'date':Timestamp.fromDate(date),'done':false}); await notifications.show(id.hashCode,'Rota Life Hatırlatıcı',t.text,const NotificationDetails(android:AndroidNotificationDetails('rota_reminders','Rota Hatırlatıcıları'))); Navigator.pop(c); }, child:const Text('Kaydet'))])); }
  @override Widget build(BuildContext context)=>SafeArea(child:Scaffold(floatingActionButton:FloatingActionButton(onPressed:()=>add(context), child:const Icon(Icons.add)), body:StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(stream:col('tasks').orderBy('date').snapshots(), builder:(c,s)=>ListView(padding:const EdgeInsets.all(16), children:[const Text('Görevler ve Hatırlatıcılar', style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)), ...?s.data?.docs.map((d){final x=d.data(); return Card(child:CheckboxListTile(value:x['done']==true,title:Text(x['title']??''), subtitle:Text(x['date'] is Timestamp ? DateFormat('dd.MM.yyyy HH:mm').format((x['date'] as Timestamp).toDate()):''), onChanged:(v)=>d.reference.update({'done':v})));})]))));
}

class EmergencyPage extends StatelessWidget { const EmergencyPage({super.key});
  Future<String> link() async { final p=await Geolocator.getCurrentPosition(); return 'https://maps.google.com/?q=${p.latitude},${p.longitude}'; }
  Future<void> open(String url) async { await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication); }
  @override Widget build(BuildContext context)=>SafeArea(child:ListView(padding:const EdgeInsets.all(16),children:[
    const Text('Acil Durum Merkezi', style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)),
    infoCard('SOS İçeriği','Tek tuşla konum linki oluşturur. Arama, SMS ve WhatsApp ile paylaşım yapılır. Kişileri Ayarlar bölümünden gir.'),
    FilledButton.icon(style:FilledButton.styleFrom(backgroundColor:Colors.red), icon:const Icon(Icons.sos), label:const Text('SOS Mesajı Oluştur'), onPressed:() async{ final l=await link(); final msg=Uri.encodeComponent('ACİL DURUM! Yardıma ihtiyacım var. Canlı konumum: $l'); await open('sms:?body=$msg'); }),
    OutlinedButton.icon(icon:const Icon(Icons.call), label:const Text('112 Ara'), onPressed:()=>open('tel:112')),
    OutlinedButton.icon(icon:const Icon(Icons.chat), label:const Text('WhatsApp ile Konum Paylaş'), onPressed:() async{ final l=await link(); await open('https://wa.me/?text=${Uri.encodeComponent('ACİL DURUM! Konumum: $l')}'); }),
  ]));
}


class PricingPage extends StatelessWidget {
  const PricingPage({super.key});
  Widget plan(String name, String price, String detail, List<String> items, {bool featured=false}) => Card(
    child: Container(
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), border: Border.all(color: featured ? const Color(0xFF39FF14) : Colors.white12, width: featured ? 2 : 1)),
      padding: const EdgeInsets.all(18),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children:[Expanded(child:Text(name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold))), if(featured) const Chip(label: Text('Önerilen'))]),
        Text(price, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: Color(0xFF39FF14))),
        const SizedBox(height: 6), Text(detail), const SizedBox(height: 12),
        ...items.map((e)=>Padding(padding: const EdgeInsets.only(bottom: 7), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children:[const Icon(Icons.check_circle, size:18, color:Color(0xFF00FFFF)), const SizedBox(width:8), Expanded(child:Text(e))]))),
        const SizedBox(height: 12), SizedBox(width: double.infinity, child: FilledButton(onPressed: (){}, child: const Text('Test İçin Seç'))),
      ])));
  @override Widget build(BuildContext context) => SafeArea(child: ListView(padding: const EdgeInsets.all(16), children: [
    const Text('Ücret Tarifesi', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
    const SizedBox(height: 8),
    infoCard('Faz 1 Notu', 'Bu ekrandaki paketler test ve iş modeli taslağıdır. Gerçek ödeme için Google Play Billing / iyzico / Stripe / banka sanal POS entegrasyonu gerekir.'),
    plan('Ücretsiz', '₺0', 'Bireysel başlangıç paketi', ['1 kullanıcı', 'Görev ve hatırlatıcı', 'Manuel acil kişi', 'SOS konum paylaşımı'], featured:false),
    plan('Life Pro', '₺99 / ay', 'Aile ve bireysel güvenlik paketi', ['5 aile üyesi', 'Canlı konum paneli', 'Gelişmiş hatırlatıcılar', 'Acil durum kişi grubu', 'Konum geçmişi - sınırlı'], featured:true),
    plan('Araç Pro', '₺199 / ay', 'Araç/servis/filo başlangıç paketi', ['3 araç kaydı', 'Araç konum servis alanı', 'Bakım ve görev hatırlatma', 'SOS + araç bilgisi paylaşımı']),
    plan('Kurumsal', '₺499+ / ay', 'İşletme ve saha operasyon paketi', ['Çoklu kullanıcı', 'Teknisyen ve ekip yönetimi', 'Servis/iş emri altyapısı', 'Firma özel fiyatlandırma']),
  ]));
}

class SettingsPage extends StatefulWidget { const SettingsPage({super.key}); @override State<SettingsPage> createState()=>_SettingsPageState(); }
class _SettingsPageState extends State<SettingsPage>{
  final name=TextEditingController(), phone=TextEditingController(), plate=TextEditingController(), vehicleName=TextEditingController();
  Future<void> addContact() async => col('contacts').add({'name':name.text,'phone':phone.text,'createdAt':FieldValue.serverTimestamp()});
  Future<void> addVehicle() async => col('vehicles').add({'plate':plate.text,'name':vehicleName.text,'status':'manuel test','createdAt':FieldValue.serverTimestamp()});
  @override Widget build(BuildContext context)=>SafeArea(child:ListView(padding:const EdgeInsets.all(16),children:[
    const Text('Ayarlar', style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)),
    infoCard('Bildirimler','Android/iOS bildirim izinlerini aç. Firebase Cloud Messaging ile sonraki fazda uzaktan bildirim aktif edilir.'),
    const Text('Acil Kişi Ekle'), TextField(controller:name, decoration:const InputDecoration(labelText:'Ad Soyad')), const SizedBox(height:8), TextField(controller:phone, decoration:const InputDecoration(labelText:'Telefon +90...')), FilledButton(onPressed:addContact, child:const Text('Kişi Kaydet')),
    const Divider(), const Text('Araç Konum Servisi Ekle'), TextField(controller:plate, decoration:const InputDecoration(labelText:'Plaka')), const SizedBox(height:8), TextField(controller:vehicleName, decoration:const InputDecoration(labelText:'Araç adı / cihaz notu')), FilledButton(onPressed:addVehicle, child:const Text('Araç Kaydet')),
    const Divider(), FilledButton.tonal(onPressed:()=>FirebaseAuth.instance.signOut(), child:const Text('Çıkış Yap'))
  ]));
}
