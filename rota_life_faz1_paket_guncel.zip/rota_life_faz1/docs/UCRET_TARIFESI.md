# ROTA LIFE Ücret Tarifesi Taslağı

## Ücretsiz İndirme
Uygulama Google Play / App Store üzerinden ücretsiz indirilir.

Kullanıcı hesap oluşturur, KVKK ve üyelik onaylarını verir, ardından demo talebi gönderir.

## Demo
- Süre: 7 gün önerilir
- Onay: Yönetici manuel onay verir
- Özellik: Temel panel, canlı konum, görev, acil durum ve araç test kaydı

## Paketler

### Ücretsiz / Demo
- 1 kullanıcı
- Görev ve hatırlatıcı
- SOS konum paylaşımı
- 1 acil kişi
- 1 araç manuel test kaydı

### Life Pro - 99 TL / ay
- 5 aile üyesi
- Canlı konum paneli
- Acil kişi grubu
- Gelişmiş hatırlatıcılar
- Konum geçmişi sınırlı

### Araç Pro - 199 TL / ay
- 3 araç kaydı
- Araç bazlı görev ve bakım hatırlatıcı
- Araç konum servis paneli
- Acil durumda araç bilgisi paylaşımı

### Kurumsal - 499 TL+ / ay
- Çoklu kullanıcı
- Ekip/teknisyen yönetimi altyapısı
- Servis/iş emri modülüne hazırlık
- Firma özel fiyatlandırma

## Ödeme Entegrasyonu
Faz 1'de ödeme ekranı taslaktır. Gerçek ödeme Faz 2'de eklenmelidir.

Önerilen yol:
1. Önce ücretsiz demo ve manuel onay
2. Sonra Google Play Billing abonelik
3. Daha sonra web ödeme paneli: iyzico / PayTR / banka sanal POS
