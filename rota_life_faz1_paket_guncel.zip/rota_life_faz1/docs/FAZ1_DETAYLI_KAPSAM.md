# ROTA LIFE FAZ 1 - Detaylı Kapsam

## Amaç
Bir insanın günlük güvenlik, konum, görev, araç ve acil durum ihtiyaçlarını tek uygulama altında test etmek.

## Faz 1 ekranları

### 1. Giriş/Kayıt
- E-posta/şifre ile giriş
- Firebase Authentication
- Kullanıcı verileri UID altında saklanır

### 2. Ana Panel
- Canlı konum özeti
- Yaklaşan görevler
- Araç konum servisleri özeti
- Acil durum bilgilendirme kartı

### 3. Harita
- Kullanıcının son konumu
- Google Maps marker
- Telefonun gerçek konum izniyle çalışır

### 4. Görevler ve Hatırlatıcılar
- Görev ekleme
- Görev tamamlama
- Firestore kayıt
- Lokal bildirim altyapısı

### 5. Acil Durum Merkezi
- SOS mesajı oluşturma
- Konum linki üretme
- SMS ekranı açma
- WhatsApp paylaşımı
- 112 arama butonu

### 6. Ayarlar
- Acil kişi ekleme
- Araç kaydı ekleme
- Bildirim açıklamaları
- Çıkış

## Canlı konum detayları

- Kullanılan paket: geolocator
- Uygulama açıkken konum izler
- 15 metre hareket filtresi vardır
- Firestore yolu: `users/{uid}/locations/self`
- Kayıt alanları:
  - lat
  - lng
  - speed
  - updatedAt

## Bağlantılar

### Firebase
- Auth: kullanıcı girişi
- Firestore: veritabanı
- Cloud Messaging: Faz 2 uzaktan bildirim için hazır altyapı

### Google Maps
- Harita gösterimi
- Konum markerı

### Telefon bağlantıları
- `tel:112`
- `sms:?body=...`
- `https://wa.me/?text=...`
- `https://maps.google.com/?q=lat,lng`

## Bildirimler

Faz 1’de lokal bildirim vardır. Zamanlı hatırlatıcı için sonraki teknik geliştirme:
- timezone paketi
- zonedSchedule
- Android exact alarm izinleri
- iOS notification permission açıklamaları

## Araç konum servisleri

Faz 1 test alanları:
- Plaka
- Araç adı / cihaz notu
- Durum

Faz 2 seçenekleri:
- Araç takip API bağlantısı
- Mobil DVR API bağlantısı
- GPS cihaz MQTT/HTTP bağlantısı
- Telefonu araç cihazı gibi kullanma

## Güvenlik ve KVKK

Bu uygulama canlı konum içerdiği için şu prensiplerle büyütülmelidir:
- Her kullanıcı kendi verisini görür
- Aile/işletme paylaşımı açık davet ile yapılır
- Konum takibi kapatılabilir olmalıdır
- Geçmiş konumlar süreli saklanmalıdır
- Hesap silme ve veri silme ekranı eklenmelidir

## Test hesabı önerisi
Kendi Firebase projenizde test hesabı açın. Hazır kullanıcı/şifre pakete koyulmadı.
