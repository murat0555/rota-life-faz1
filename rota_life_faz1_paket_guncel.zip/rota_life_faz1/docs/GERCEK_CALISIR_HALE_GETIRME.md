# ROTA LIFE - Gerçek Çalışır Hale Getirme Planı

Bu paket Faz 1 test uygulamasıdır. Gerçek çalışır hale gelmesi için aşağıdaki servislerin bağlanması gerekir.

## 1) Firebase Authentication
Aktif edilecek giriş yöntemleri:

- E-posta / şifre
- Telefon doğrulama
- Google hesabı ile giriş

Firebase Console > Authentication > Sign-in method bölümünden bu üç yöntem açılır.

Telefon doğrulama için Firebase üzerinde SMS doğrulama kotası ve ülke izinleri kontrol edilmelidir. İlk hedef ülke Türkiye ise varsayılan telefon formatı `+90` olmalıdır.

## 2) KVKK ve Onay Kayıtları
Kayıt sırasında şu onaylar alınır:

- KVKK Aydınlatma Metni okundu
- Açık rıza verildi
- Üyelik koşulları kabul edildi
- Ticari ileti izni opsiyonel

Bu onaylar Firestore `users/{uid}` içine şu alanlarla kaydedilir:

```text
country
authMethod
kvkkAydinlatmaOkundu
acikRizaOnayi
uyelikKosullariOnayi
ticariIletiOnayi
consentVersion
consentAt
```

Yayına çıkmadan önce KVKK metni firmanın gerçek bilgileriyle avukata kontrol ettirilmelidir.

## 3) Demo Talebi ve Yönetici Onayı
Uygulama ücretsiz indirilir. Kullanıcı hesap oluşturduktan sonra uygulama ana paneli açılmaz. Önce Demo Talebi ekranı gelir.

Kullanıcı demo talebi gönderince:

```text
demoRequests/{uid}
users/{uid}.demoStatus = pending
users/{uid}.accountStatus = waiting_admin_approval
```

Sen onay verince:

```text
users/{uid}.demoStatus = approved
users/{uid}.accountStatus = active
demoRequests/{uid}.status = approved
```

Bu işlemden sonra kullanıcı ana uygulama paneline erişir.

## 4) E-posta ile Onay Bildirimi
Paket içinde `functions/index.js` örnek Cloud Function vardır. Bu fonksiyon yeni demo talebi geldiğinde yöneticiye e-posta gönderir.

SMTP için gerekli bilgiler:

```text
SMTP_HOST=mail.rotasecteknoloji.com
SMTP_PORT=465
SMTP_SECURE=true
SMTP_USER=bilgi@rotasecteknoloji.com
SMTP_PASS=MAIL_SIFRESI
SMTP_FROM="ROTA LIFE <bilgi@rotasecteknoloji.com>"
ADMIN_EMAIL=ONAY_MAIL_ADRESIN
```

Cloud Functions ortam değişkenleri ile girilmelidir. Şifre kod içine yazılmamalıdır.

## 5) Google Maps
Google Cloud Console'da Maps SDK for Android açılır. API key alınır ve `AndroidManifest.xml` içine yazılır.

## 6) Bildirimler
Faz 1 içinde lokal bildirim vardır. Gerçek uzaktan bildirim için Firebase Cloud Messaging eklenecek.

Demo onayı, görev hatırlatma ve acil durum bildirimi için önerilen yapı:

- Firebase Cloud Messaging
- Cloud Functions
- Firestore trigger

## 7) Ücret Tarifesi
Uygulama ücretsiz indirilir. Demo onayı sonrası paket seçimi yapılır.

Önerilen ilk tarife:

```text
Ücretsiz Demo: 7 gün / sınırlı özellik
Life Pro: 99 TL / ay
Araç Pro: 199 TL / ay
Kurumsal: 499 TL+ / ay
```

Gerçek ödeme için seçenekler:

- Google Play Billing: Android abonelikleri için en doğru yöntem
- Apple In-App Purchase: iOS için gerekir
- iyzico / PayTR / banka sanal POS: web panel üzerinden ödeme için

Mobil uygulama içinden dijital abonelik satılacaksa Google Play ve Apple ödeme kurallarına dikkat edilmelidir.

## 8) Yayın Öncesi Zorunlu Sayfalar

- Gizlilik Politikası
- KVKK Aydınlatma Metni
- Açık Rıza Metni
- Kullanım Koşulları
- Veri Silme Talebi Sayfası
- İletişim / destek sayfası

## 9) Senden Gereken Bilgiler

Aşağıdaki bilgiler olmadan uygulama gerçek yayına alınamaz:

1. Uygulama adı kesin karar: Rota Life / RotaLife / başka ad
2. Paket adı: örnek `com.rotasec.rotalife`
3. Yönetici onay e-postası
4. SMTP e-posta şifresi veya uygulama şifresi
5. Firma tam unvanı
6. Firma adresi
7. Vergi no / MERSİS varsa
8. KVKK başvuru e-postası
9. Destek telefon numarası
10. Destek WhatsApp numarası
11. Google Play geliştirici hesabı
12. Firebase proje adı
13. Google Maps API key
14. Demo süresi: 7 gün mü, 14 gün mü?
15. Demo sonrası otomatik kapanma olacak mı?
16. Kullanıcı onayı manuel mi, otomatik paket ödemesiyle mi aktif olacak?
