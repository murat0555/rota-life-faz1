# ROTA LIFE FAZ 1 - Kurulum ve Test Rehberi

Bu paket test edilebilir Faz 1 MVP kaynak paketidir. İçinde canlı konum, harita, görev/hatırlatıcı, araç kayıt servisi, acil durum merkezi, acil kişiler ve Firebase veri yapısı vardır.

## 1) Bilgisayara kurulacaklar

1. Flutter SDK kur.
2. Android Studio kur ve Android SDK + emulator kur.
3. VS Code kur, Flutter ve Dart eklentilerini yükle.
4. Node.js LTS kur.
5. Firebase CLI kur:

```bash
npm install -g firebase-tools
```

6. FlutterFire CLI kur:

```bash
dart pub global activate flutterfire_cli
```

Firebase’in resmi Flutter kurulumunda `flutterfire configure` ile `firebase_options.dart` oluşturulması önerilir. FlutterFire CLI bu konfigürasyonu otomatik üretir.

## 2) Firebase projesi oluşturma

1. Firebase Console aç.
2. Yeni proje oluştur: `rota-life-test`
3. Authentication > Sign-in method > Email/Password aktif et.
4. Firestore Database oluştur. İlk test için production mode seçebilirsin, sonra `firebase/firestore.rules` dosyasındaki kuralları yükle.
5. Project settings > Android app ekle.
   - Package name örnek: `com.rotasec.rotalife`
6. `google-services.json` dosyasını indir.
7. FlutterFire ile proje kökünde çalıştır:

```bash
flutterfire configure
```

Bu işlem `lib/firebase_options.dart` oluşturur.

## 3) Google Maps API

1. Google Cloud Console üzerinden Maps SDK for Android aktif edilir.
2. API key alınır.
3. `android/app/src/main/AndroidManifest.xml` içinde şu alan değiştirilir:

```xml
<meta-data android:name="com.google.android.geo.API_KEY" android:value="GOOGLE_MAPS_API_KEY_BURAYA"/>
```

## 4) Projeyi çalıştırma

Paket klasöründe:

```bash
flutter pub get
flutter run
```

APK almak için:

```bash
flutter build apk --release
```

APK yolu:

```text
build/app/outputs/flutter-apk/app-release.apk
```

## 5) Test senaryosu

1. Uygulamayı aç.
2. Kayıt Ol ile test hesabı aç.
3. Konum iznini ver.
4. Panel ekranında canlı konum koordinatını gör.
5. Harita sekmesinde konum markerını gör.
6. Görev sekmesinden görev ekle.
7. Acil sekmesinden SMS/WhatsApp konum mesajını dene.
8. Ayarlar sekmesinden acil kişi ve araç kaydı ekle.
9. Firebase Firestore’da `users/{uid}` altında kayıtların oluştuğunu kontrol et.

## 6) Faz 1 veri yapısı

```text
users/{uid}
  contacts/{contactId}: name, phone
  vehicles/{vehicleId}: plate, name, status
  tasks/{taskId}: title, date, done
  locations/self: lat, lng, speed, updatedAt
```

## 7) Canlı konum mantığı

Uygulama açıkken GPS akışını dinler. Kullanıcı 15 metre civarı hareket ettiğinde Firestore’a güncel koordinatı yazar. Bu yapı aile/işletme takip ekranına genişletilebilir.

Not: Arka planda sürekli konum için Android/iOS tarafında ek izin, açıklama metni, Play Store KVKK/gizlilik açıklaması ve foreground service mimarisi gerekir. Bu paket test sürümü olarak uygulama açıkken canlı konum sağlar.

## 8) Bildirim ve hatırlatıcı

Paket içinde lokal bildirim altyapısı eklidir. Görev eklendiğinde anlık test bildirimi gösterir. Zamanlı bildirim için bir sonraki sürümde timezone destekli planlama eklenir. Uzaktan bildirim için Firebase Cloud Messaging hazır bağımlılık olarak eklenebilir.

## 9) Acil durum merkezi

SOS modülü anlık konum linki üretir:

```text
https://maps.google.com/?q=LAT,LNG
```

Sonra SMS, WhatsApp veya telefon araması açar. Gerçek gönderim kullanıcı onayıyla telefondaki ilgili uygulama üzerinden yapılır.

## 10) Araç konum servisi

Faz 1’de araçlar manuel kayıt edilir. Faz 2’de GPS cihazı, mobil DVR, takip API’si veya kullanıcı telefon konumu araçla eşleştirilebilir.

## 11) Önemli mağaza ve gizlilik uyarısı

Canlı konum, acil kişi, aile takibi gibi özellikler KVKK ve açık rıza gerektirir. Yayına almadan önce:

- Gizlilik politikası
- Konum kullanım açıklaması
- Kullanıcı onayı
- Veri silme talebi
- Çocuk/aile kullanımı için açık izin

hazırlanmalıdır.

## 12) Yeni Eklenen Kayıt / Demo Onay Akışı

Bu güncel pakette açılış ekranına Giriş Yap ve Kayıt Ol menüleri eklendi.

Kayıt seçenekleri:

- E-posta ile kayıt
- Telefon SMS doğrulama ile kayıt
- Google hesabı ile kayıt

Kayıt sırasında ülke seçimi, KVKK aydınlatma metni, açık rıza, üyelik koşulları ve opsiyonel ticari ileti izni alınır.

Kullanıcı kayıt olunca uygulama direkt açılmaz. Demo talebi ekranına düşer.

Onay için Firebase Console'da:

```text
Firestore > users > UID
```

alanında şu değerleri yap:

```text
demoStatus = approved
accountStatus = active
```

Ayrıca:

```text
Firestore > demoRequests > UID
status = approved
```

yapabilirsin.

## 13) Yöneticiye E-posta Bildirimi

`functions/` klasöründe örnek Firebase Cloud Function hazırdır. Bu fonksiyon demo talebi oluşunca sana e-posta gönderir.

Kurulum özeti:

```bash
cd functions
npm install
firebase deploy --only functions
```

SMTP bilgilerini güvenli ortam değişkeni olarak girmen gerekir. Ayrıntı için `docs/GERCEK_CALISIR_HALE_GETIRME.md` dosyasına bak.

## 14) Ücret Tarifesi

Uygulamada Paket sekmesi eklendi. Faz 1'de ödeme tahsilatı yoktur, tarife ekranı ve demo/paket seçimi vardır. Gerçek abonelik Faz 2'de Google Play Billing veya iyzico/PayTR ile bağlanır.
