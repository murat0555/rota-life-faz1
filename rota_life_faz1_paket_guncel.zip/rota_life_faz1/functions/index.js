const functions = require('firebase-functions');
const admin = require('firebase-admin');
const nodemailer = require('nodemailer');
admin.initializeApp();

function mailer() {
  return nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 465),
    secure: String(process.env.SMTP_SECURE || 'true') === 'true',
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
  });
}

exports.onDemoRequest = functions.firestore
  .document('demoRequests/{uid}')
  .onWrite(async (change, context) => {
    const after = change.after.exists ? change.after.data() : null;
    if (!after) return null;
    const adminEmail = process.env.ADMIN_EMAIL;
    if (!adminEmail) return null;
    const uid = context.params.uid;
    const subject = after.status === 'approved' ? 'ROTA LIFE demo onaylandı' : 'Yeni ROTA LIFE demo talebi';
    const body = `
Yeni demo talebi / güncelleme:

UID: ${uid}
Ad: ${after.displayName || '-'}
E-posta: ${after.email || '-'}
Telefon: ${after.phone || '-'}
Firma: ${after.company || '-'}
Paket: ${after.requestedPlan || '-'}
Durum: ${after.status || '-'}
Not: ${after.note || '-'}

Onay vermek için Firebase Console > Firestore > users/${uid} alanında:
demoStatus = approved
accountStatus = active

Aynı şekilde demoRequests/${uid} içinde status = approved yap.
`;
    await mailer().sendMail({ from: process.env.SMTP_FROM, to: adminEmail, subject, text: body });
    return null;
  });
